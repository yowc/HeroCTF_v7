package com.challenge.drive.config;

public class Constants {
    public static final String EMAIL_PATH = "/tmp/emails.txt";
    public static final String UPLOAD_DIR = "uploads/";
}
